sentence = list(map(str, input().split()))
print(len(sentence))